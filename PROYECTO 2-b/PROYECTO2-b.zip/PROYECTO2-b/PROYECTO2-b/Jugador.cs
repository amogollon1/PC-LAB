﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2_b
{
    /// <summary>
    /// Esta clase contiene las propiedades y métodos que definen a cada jugador.
    /// </summary>
    class Jugador
    {
        //Declaración e iniciación de propiedades
        public string nickname { get; set; }
        public int punteo = 0;
        public bool recibiImpacto;
        public string[,] tableroFlota = new string[6, 6];
        public string[,] tableroAtaques = new string[6, 6];
        
        //Constantes
        //Imprimir en tablero
        private static readonly string Agua = "~";
        private static readonly string Fallo = "X";
        private static readonly string Acierto = "O";
        public Barcos BarcosJugador;
        /// <summary>
        /// Inicializa variables y métodos que se realizan al momento de instanciar un nuevo jugador
        /// </summary>
        /// <param name="_nickname">Recibe el nickname ingresado por el usuario y lo asigna a la instancia del jugador</param>
        public Jugador(string _nickname)
        {
            this.nickname = _nickname;
            InicializarTableroAtaque();
            InicializarTableroFlota();
            this.BarcosJugador = new Barcos();
        }
        /// <summary>
        /// Este método imprime el tablero de la flota de cada jugador.
        /// </summary>
        public void MostrarTableroFlota()
        {
            Console.Write($"  1 2 3 4 5 6\n");
            for (int i = 0; i < 6; i++)
            {
                char letra = (char)('A' + i);
                Console.Write($"{letra} ");
                for (int j = 0; j < 6; j++)
                {
                    Console.Write($"{this.tableroFlota[i, j]} ");
                }
                Console.WriteLine(" ");
            }
        }
        /// <summary>
        /// Este método imprime ambos tableros del jugador.
        /// </summary>
        public void MostrarTableros()
        {
            Console.Write($" \nTablero Flota\tTablero Ataques\n");
            Console.Write($"  1 2 3 4 5 6\t  1 2 3 4 5 6\n");
            for (int i = 0; i < 6; i++)
            {
                char letra = (char)('A' + i);
                Console.Write($"{letra} ");
                for (int j = 0; j < 6; j++)
                {
                    Console.Write($"{this.tableroFlota[i, j]} ");
                }
                Console.Write("\t");
                Console.Write($"{letra} ");
                for (int j = 0; j < 6; j++)
                {
                    Console.Write($"{this.tableroAtaques[i, j]} ");
                }
                Console.WriteLine(" ");
            }
        }
        /// <summary>
        /// Este método asigna el valor predeterminado al tablero de ataques.
        /// </summary>
        public void InicializarTableroAtaque()
        {
            for(int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    this.tableroAtaques[i, j] = Agua;
                }
            }
        }
        /// <summary>
        /// Este método asigna el valor predeterminado al tablero de la flota.
        /// </summary>
        public void InicializarTableroFlota()
        {
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    this.tableroFlota[i, j] = Agua;
                }
            }
        }
        /// <summary>
        /// Este método compara el valor del tablero para saber si la casilla está ocupada o no, en caso de estar ocupada (ser diferente de 'Agua') se rompre el ciclo
        /// y se devuelve un false para que se generen nuevas posiciones, caso contrario devuelve true y el barco queda validado.
        /// </summary>
        /// <param name="orientacion">Recibe como argumento la orientación (vertical u horizontal) como un 0 o un 1</param>
        /// <param name="tamaño">Recibe como arguento la cantidad de casillas que ocupa el barco para delimitar la cantidad de espacios que debe validar el ciclo for.</param>
        /// <param name="arregloPosicion">Recibe como argumento un arreglo que contiene las coordenadas iniciales del barco.</param>
        /// <returns></returns>
        public bool ValidarPosicionBarcos(int orientacion, int tamaño, int[] arregloPosicion)
        {
            bool exito = false;
            if(orientacion == 0)
            {
                for (int i = 0; i < tamaño; i++)
                {
                    if (this.tableroFlota[arregloPosicion[0] + i, arregloPosicion[1]] != Agua)
                    {
                        exito = false;
                        break;
                    }
                    exito = true;
                }
            }
            if (orientacion == 1)
            {
                for (int i = 0; i < tamaño; i++)
                {
                    if (this.tableroFlota[arregloPosicion[0], arregloPosicion[1] + i] != Agua)
                    {
                        exito = false;
                        break;
                    }
                    exito = true;
                }
            }
            return exito;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="orientacion"></param>
        /// <param name="tamaño"></param>
        /// <param name="arregloPosicion"></param>
        /// <param name="asignarValor"></param>
        public void AsignarValorBarcosEnTablero(int orientacion, int tamaño, int[] arregloPosicion, string asignarValor)
        {
            if(orientacion == 0)
            {
                for (int i = 0; i < tamaño; i++)
                {
                    this.tableroFlota[arregloPosicion[0] + i, arregloPosicion[1]] = asignarValor;
                }
            }
            if (orientacion == 1)
            {
                for (int i = 0; i < tamaño; i++)
                {
                    this.tableroFlota[arregloPosicion[0], arregloPosicion[1] + i] = asignarValor;
                }
            }
        }
        /// <summary>
        /// Se valida que la posición que ocupa el submarino no esté ocupada, una vez validada se asigna al tablero el valor del submarino ("S").
        /// </summary>
        public void ValidarSubmarino()
        {
            bool posicionValida;
            do
            {
                BarcosJugador.PosicionSubmarino();
                posicionValida = this.ValidarPosicionBarcos(1, 2, BarcosJugador.submarino);
                if(posicionValida == true)
                {
                    AsignarValorBarcosEnTablero(1, 2, BarcosJugador.submarino, "S");
                }
                
            }while(posicionValida == false);
        }
        /// <summary>
        /// Se valida que la posición que ocupa la fragata no esté ocupada, una vez validada se asigna al tablero el valor de fragata ("F").
        /// </summary>
        public void ValidarFragata()
        {
            bool posicionValida;
            do
            {
                BarcosJugador.PosicionFragata();
                posicionValida = this.ValidarPosicionBarcos(0, 3, BarcosJugador.fragata);
                if (posicionValida == true)
                {
                    AsignarValorBarcosEnTablero(0, 3, BarcosJugador.fragata, "F");
                }
            } while (posicionValida == false);
        }
        /// <summary>
        /// Se valida que la posición que ocupa el destructor no esté ocupada, una vez validada se asigna al tablero el valor del destructor ("D").
        /// </summary>
        public void ValidarDestructor()
        {
            bool posicionValida;
            do
            {
                BarcosJugador.PosicionDestructor();
                posicionValida = this.ValidarPosicionBarcos(BarcosJugador.orientacionDestructor, 4, BarcosJugador.destructor);
                if (posicionValida == true)
                {
                    AsignarValorBarcosEnTablero(BarcosJugador.orientacionDestructor, 4, BarcosJugador.destructor, "D");
                }
            } while (posicionValida == false);
        }
        /// <summary>
        /// Se asigan las posiciones de los tres barcos luego de haberse validado, llamando a los métodos individuales de validación de cada uno.
        /// </summary>
        public void AsignarBarcos()
        {
            ValidarSubmarino();
            ValidarFragata();
            ValidarDestructor();
        }
        //Valida si las coordenadas de ataque coinciden con las de un barco
        public void ValidarImpactoAtacante(Jugador atacante, Jugador oponente, int[] coordenada)
        {
            bool impacto;
            //Modifica el impacto en la flota oponente
            if (oponente.tableroFlota[coordenada[0], coordenada[1]] != Agua)
            {
                Console.WriteLine("¡Haz impactado un barco!");
                atacante.PunteoImpacto(oponente, coordenada); //punteo y modificar tableros
                impacto = true;
                
                ModificarTableros(atacante, oponente, impacto, coordenada);
            }
            else
            {
                Console.WriteLine("Haz fallado.");
                atacante.tableroAtaques[coordenada[0], coordenada[1]] = Fallo;
                impacto = false;
            }
        }
        /// <summary>
        /// Valida barco por barco si ha sido hundido, en caso de serlo, le brinda os puntos al jugador que ataca, según el tipo de barco.
        /// </summary>
        /// <param name="oponente">Recibe como argumento el jugador que no está atacando para realizar algunas validaciones</param>
        /// <param name="coordenadas">Recibe como argumento las coordenadas donde se ha impactado</param>
        public void PunteoImpacto(Jugador oponente, int[] coordenadas)
        {
            
            if (oponente.tableroFlota[coordenadas[0], coordenadas[1]] == "S")
            {
                oponente.BarcosJugador.vidaSubmarino -= 1;
                if(oponente.BarcosJugador.vidaSubmarino == 0)
                {
                    Console.WriteLine("¡Haz hundido al submarino! ¡Ganas 2 puntos!");
                    this.punteo += 2;
                }
            }
            else if (oponente.tableroFlota[coordenadas[0], coordenadas[1]] == "F")
            {
                oponente.BarcosJugador.vidaFragata -= 1;
                if (oponente.BarcosJugador.vidaFragata == 0)
                {
                    Console.WriteLine("¡Haz hundido la Fragata! ¡Ganas 3 puntos!");
                    this.punteo += 3;
                }
            }
            else if (oponente.tableroFlota[coordenadas[0], coordenadas[1]] == "D")
            {
                oponente.BarcosJugador.vidaDestructor -= 1;
                if (oponente.BarcosJugador.vidaDestructor == 0)
                {
                    Console.WriteLine("¡Haz hundido al Destructor! ¡Ganas 4 puntos!");
                    this.punteo += 4;
                }
            }
        }
        /// <summary>
        /// Valida que el jugador haya, o no, recibido un impacto para notificarselo.
        /// </summary>
        /// <param name="recibiImpacto">Recibe como argumento un bool que indica si el jugador recibió un impacto</param>
        public void ValidarImpactoOponente(bool recibiImpacto)
        {
            if(recibiImpacto == true)
            {
                Console.WriteLine("¡Haz recibido un impacto!");
                recibiImpacto = false;
            }
        }
        /// <summary>
        /// En caso de que se cumpla la condición, el método modifica los valores que se muestran en el tablero del jugador.
        /// </summary>
        /// <param name="atacante">Recibe como argumento el jugador que está atacando</param>
        /// <param name="oponente">Recibe como argumento el jugador que está siendo atacado</param>
        /// <param name="impacto">Recibe como argumento un bool que indica si el jugador recibió, o no, un impacto</param>
        /// <param name="coordenada">Recibe como argumento la coordenada donde se realizó el ataque</param>
        /// <returns>Devuelve un bool que indica si se modificó el tablero, o no</returns>
        public bool ModificarTableros(Jugador atacante, Jugador oponente, bool impacto, int[] coordenada)
        {
            bool modificar;
            if(impacto == true)
            {
                atacante.tableroAtaques[coordenada[0], coordenada[1]] = Acierto;
                oponente.tableroFlota[coordenada[0], coordenada[1]] = Acierto;
                oponente.recibiImpacto = true;
                modificar = true;
            }
            else
            {
                modificar = false;
            }
                return modificar;
        }
        /// <summary>
        /// Valida si el jugador aún cuenta con barcos a flote.
        /// </summary>
        /// <returns>Devuelve un bool que indica si el jugador aún sigue con vida</returns>
        public bool BarcosConVida()
        {
            bool vivo = true;
            if(BarcosJugador.vidaSubmarino == 0 && BarcosJugador.vidaFragata == 0 && BarcosJugador.vidaDestructor == 0)
            {
                vivo = false;
            }
            return vivo;
        }
        /// <summary>
        /// Valida si el jugador ingresó una coordenada repetida, en la que ya realizó un ataque.
        /// </summary>
        /// <param name="coordenadas">Recibe como argumento las coordenadas de ataque ingresadas por el usuario</param>
        /// <returns></returns>
        public bool ValidarCoordenadaRepetida(int[] coordenadas)
        {
            bool repetida = false;
            if (this.tableroAtaques[coordenadas[0], coordenadas[1]] != Agua)
            {
                Console.WriteLine($"Ya haz atacado en esta coordenada.");
                repetida = true;
            }
            return repetida;
        }
    }
}