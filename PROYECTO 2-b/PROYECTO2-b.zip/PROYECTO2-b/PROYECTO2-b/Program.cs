﻿using System.Numerics;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

namespace PROYECTO2_b
{
    class Program
    {
        /// <summary>
        /// Método pincipal, donde se realizar las acciones principales del programa
        /// </summary>
        public static void Main()
        {
            //Definir variables
            string nickname;
            string[,] tableroFlota = new string[6, 6];
            string[,] tableroAtaques = new string[6, 6];
            bool rendirse;
            bool barcosVivos;
            bool ejecutar = true;
            int turno = 1;

            //Datos de Entrada
            do
            {
                //Menu inicial
                MenuInicial();
                //Datos Jugador 1
                do
                {
                    //Se pide al usuario que ingrese su nickname (se repite hasta que el campo deje de estar en blanco).
                    Console.WriteLine("Jugador 1, ingresa tu nombre de ususario: ");
                    nickname = Console.ReadLine();
                } while (string.IsNullOrEmpty(nickname));
                //Se instancia al Jugador1 en base a la clase Jugador
                Jugador player1 = new Jugador(nickname);
                //Se llama al método InicializarJugador
                InicializarJugador(player1);
                //Datos Jugador 2
                do
                {
                    Console.WriteLine("Jugador 2, ingresa tu nombre de ususario: ");
                    nickname = Console.ReadLine();
                } while (string.IsNullOrEmpty(nickname));
                Jugador player2 = new Jugador(nickname);
                InicializarJugador(player2);
                do
                {
                    //Turno Jugador 1
                    TiempoCarga(player1);
                    InterfazTurnos(player1.nickname, turno, player1.punteo);
                    player1.MostrarTableros();
                    player1.ValidarImpactoOponente(player1.recibiImpacto);
                    rendirse = DecisionTurno(player1, player2);
                    barcosVivos = player2.BarcosConVida();
                    ejecutar = Continuar(rendirse, barcosVivos);
                    if(ejecutar == false)
                    {
                        break;
                    }
                    Console.WriteLine($"Presiona cualquier tecla para continuar.");
                    Console.ReadKey();

                    //Turno Jugador 2
                    TiempoCarga(player2);
                    InterfazTurnos(player2.nickname, turno, player2.punteo);
                    player2.MostrarTableros();
                    player2.ValidarImpactoOponente(player2.recibiImpacto);
                    rendirse = DecisionTurno(player2, player1);
                    barcosVivos = player1.BarcosConVida();
                    ejecutar = Continuar(rendirse, barcosVivos);
                    if (ejecutar == false)
                    {
                        break;
                    }
                    Console.WriteLine($"Presiona cualquier tecla para continuar.");
                    Console.ReadKey();

                    turno++;
                } while (turno <= 15);
                //Resultados
                Resultados(player1, player2);
                //Se llama al método que consulta si se desea volver a jugar
                ejecutar = JugarNuevamente();
            } while (ejecutar == true);
        }
        /// <summary>
        /// Se muestra el tablero con la posición aleatoria de los barcos del jugador instanciado, por el método MostrarTableroFlota();.
        /// Posteriormente se le pide al usuario que decida si desea confirmar la posición generada o si prefiere que se generen nuevas posiciones.
        /// Las posiciones se generan por medio del método AsignarBarcos();. En caso de confirmar se asignan los barcos al tablerFlota[] del jugador
        /// y se acaba el método. El método se repite en caso de no recibir valores válidos (1 o 2).
        /// </summary>
        /// <param name="player">Este parámetro se refiere al jugador que está siendo inicializado</param>
        public static void InicializarJugador(Jugador player)
        {
            bool ejecutar = true;
            do
            {
                while (true)
                {
                    Console.WriteLine("La posición de sus barcos es la siguiente: \n");
                    player.AsignarBarcos();
                    player.MostrarTableroFlota();
                    Console.Write("\n¿Confirmar la posición actual de los barcos?");
                    Console.WriteLine(" (No podrá modificarla despues).");
                    Console.WriteLine("1. Si\n2. No");
                    if (int.TryParse(Console.ReadLine(), out int confirmar) && confirmar > 0 && confirmar <= 2)
                    {
                        if (confirmar == 1)
                        {
                            Console.Write("Posición confirmada");
                            Console.Write("\tPresione cualquier tecla para continuar.");
                            Console.ReadKey();
                            Console.Clear();
                            ejecutar = false;
                        }
                        else
                        {
                            player.InicializarTableroFlota();
                            ejecutar = true;
                            Console.Clear();
                        }
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Valor inválido. Inténtelo de nuevo.");
                        player.InicializarTableroFlota();
                    }
                }
            } while (ejecutar == true);
        }
        /// <summary>
        /// Este método genera un tiempo de espera de 3 segundos entre turnos.
        /// </summary>
        /// <param name="player">Este argumento llama al nickname del jugador al que le toca atacar para mostrar un mensaje personalizado</param>
        public static void TiempoCarga(Jugador player)
        {
            Console.Clear();
            Console.WriteLine($"{player.nickname}, preparate tu turno inicia en:");
            for(int i = 3; i >= 1; i--)
            {
                Console.WriteLine($"{i}");
                Thread.Sleep(1000);
            }
            Console.WriteLine($"¡Ataca!");
            Thread.Sleep(500);
            Console.Clear();
        }
        /// <summary>
        /// Este método muestra la información que cada usuario debe ver en su turno, su nombre, el número de turno y los puntos acumulados.
        /// </summary>
        /// <param name="nickname">Recibe el nickname del jugador que ataca</param>
        /// <param name="turnos">Recibe el número de turno para mostrarlo</param>
        /// <param name="puntos">Recibe la cantidad de puntos acumulados para mostrarlos</param>
        public static void InterfazTurnos(string nickname, int turnos, int puntos)
        {
            Console.Write($"{nickname} es tu turno.\t");
            Console.Write($"Turno {turnos}\t");
            Console.Write($"Puntos: {puntos}\n");
        }
        /// <summary>
        /// Pregunta al usuario qué desea hacer en su turno (atacar o rendirse).
        /// </summary>
        /// <param name="atacante">Recibe al jugador que ataca como argumento para validar varias acciones y cambios en sus propiedades</param>
        /// <param name="oponente">Recibe al jugador oponente como argumento para validar varias acciones y cambios en sus propiedades</param>
        /// <returns>Devuelve un valor booleano que determina si el jugador decidió seguir jugando o se rindió</returns>
        public static bool DecisionTurno(Jugador atacante, Jugador oponente)
        {
            bool continuar = true;
            bool ejecutar = true;
            string coordenadas;
            Regex regex = new Regex(@"^[A-Fa-f]-[1-6]$");
            do
            {
                Console.WriteLine("Elige una opción:\n1. Atacar\n2. Rendirse");
                if (int.TryParse(Console.ReadLine(), out int eleccion) && eleccion > 0 && eleccion <= 2)
                {
                    if (eleccion == 1)
                    {
                        bool repetir = false;
                        do
                        {
                            Console.WriteLine("Ingresa las coordenadas de ataque: ");
                            Console.WriteLine("Deben seguir el siguiente formato: LETRA-NÚMERO (A-3).");
                            coordenadas = Console.ReadLine();

                            if (regex.IsMatch(coordenadas))
                            {
                                int[] coordenadaAtacada = ExtraerPuntoAtacado(coordenadas.ToUpper());
                                if(atacante.ValidarCoordenadaRepetida(coordenadaAtacada) == false)
                                {
                                    oponente.ValidarImpactoAtacante(atacante, oponente, coordenadaAtacada);
                                    ejecutar = false;
                                    repetir = false;
                                    break;
                                }
                                else
                                {
                                    Console.WriteLine("Coordenadas inválidas. Intenta de nuevo.");
                                    repetir = true;
                                }
                            }
                            else
                            {
                                Console.WriteLine("Coordenadas inválidas. Intenta de nuevo.");
                                repetir = true;
                            }
                        } while (string.IsNullOrEmpty(coordenadas) || repetir);
                    }
                    else
                    {
                        Console.WriteLine($"{atacante.nickname} te haz rendido.\n");
                        atacante.punteo = -1;
                        continuar = false;
                        ejecutar = false;
                    }
                }
                else
                {
                    Console.WriteLine("Valor inválido. Inténtelo de nuevo.");
                }
            } while (ejecutar == true);
            
                return continuar;
        }
        /// <summary>
        /// Recibe las coordenadas de ataque (LETRA-NUMERO) y las convierte en coordenadas enteras que se pueden interpretar en las matrices.
        /// </summary>
        /// <param name="coordenadas">Recibe el string ingresado por el usuario como coordenada</param>
        /// <returns>Un arrreglo entero con dos valores enteros, las coordenadas de ataque</returns>
        public static int[] ExtraerPuntoAtacado(string coordenadas)
        {
            int[] coordenada = new int[2];
            string indiceLetra = "ABCDEF";
            string indiceNumeros = "123456";
            string coordenadaMayuscula = coordenadas.Trim().ToUpper();

            string[] coordenadasAtaque = coordenadaMayuscula.Split('-');
            string fila = coordenadasAtaque[0];
            int filaAtaque = indiceLetra.IndexOf(fila);
            string columna = coordenadasAtaque[1];
            int columnaAtaque = indiceNumeros.IndexOf(columna);
            coordenada[0] = filaAtaque;
            coordenada[1] = columnaAtaque;

            return coordenada;
        }
        /// <summary>
        /// Compara los puntos acumulados de los jugadores y determina quien es el ganador.
        /// </summary>
        /// <param name="player1">Recibe la instancia del jugador uno para obtener la cantidad de puntos que ha acumulado</param>
        /// <param name="player2">Recibe la instancia del jugador dos para obtener la cantidad de puntos que ha acumulado</param>
        public static void Resultados(Jugador player1, Jugador player2)
        {
            if(player1.punteo > player2.punteo)
            {
                Console.WriteLine($"\n¡{player1.nickname}! ¡Eres el vencedor!\n");
            }
            else if (player1.punteo < player2.punteo)
            {
                Console.WriteLine($"\n¡{player2.nickname}! ¡Eres el vencedor!\n");
            }
            else
            {
                Console.WriteLine("\n¡Ha sido un empate!\n"); 
            }
        }
        /// <summary>
        /// Determina, al finalizar cada turno, si se cumple alguna de las condiciones que finalizan el juego.
        /// </summary>
        /// <param name="rendirse">Recibe un bool que determina si el usuario se rindió.</param>
        /// <param name="barcosVivos">Recibe un bool que determina si el usuario aún cuenta con barcos a flote</param>
        /// <returns>Devuelve un bool que indica si se debe finalizar el juego o no</returns>
        public static bool Continuar(bool rendirse, bool barcosVivos)
        {
            bool continuar = true;
            if(rendirse == false)
            {
                continuar = false;
            }
            else if(barcosVivos == false)
            {
                continuar = false;
            }
                return continuar;
        }
        /// <summary>
        /// Al finalizar el juego, se le pregunta al usuario si desea finalizar o volver a jugar.
        /// </summary>
        /// <returns>Devuelve un bool que determina si se debe continuar con el ciclo que inicia el juego o si se sale del mismo</returns>
        public static bool JugarNuevamente()
        {
            bool ejecutar;
            while (true)
            {
                Console.WriteLine($"¿Deseas volver a jugar?");
                Console.WriteLine($"1. Si\n2. No");
                if (int.TryParse(Console.ReadLine(), out int confirmar) && confirmar > 0 && confirmar <= 2)
                {
                    if (confirmar == 1)
                    {
                        Console.Write("Reiniciando...");
                        Console.Write("\tPresione cualquier tecla para continuar.");
                        Console.ReadKey();
                        Console.Clear();
                        ejecutar = true;
                        break;
                    }
                    else
                    {
                        Console.Write($"Cerrando...");
                        Console.Write($"\t¡Gracias por jugar!");
                        ejecutar = false;
                        Thread.Sleep(2000);
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("Valor inválido. Inténtelo de nuevo."); 
                }
            }
            return ejecutar;
        }
        /// <summary>
        /// Muestra el menú, donde se muestra información que gupia al usuario al jugar.
        /// </summary>
        public static void MenuInicial()
        {
            Console.Write($"\t\t\t\t\t¡Bienvenidos a Flota Naval!\n");
            Console.Write($"\t\tEn este juego dos jugadores intentarán hundir la flota enemiga antes que se terminen sus misiles. " +
                $"\n\t\tCada jugador cuenta con 15 disparos para intentar destruir los barcos del oponente. " +
                $"\r\n\t\t¡Gana el jugador que logre hundir la mayor cantidad de barcos enemigos!\n");

            Console.WriteLine($"\n\nCada jugador cuenta con tres barcos representados por letras dependiendo de su tipo." +
                $"\nSubmarino: ocupa 2 casillas en el tablero, de manera horizontal, al ser hundido otorga 2 puntos al atacante,\nestá representado por la letra 'S'." +
                $"\nFragata: ocupa 3 casillas en el tablero, de manera vertical, al ser hundido otorga 3 puntos al atacante,\nestá representado por la letra 'F'." +
                $"\nFragata: ocupa 4 casillas en el tablero, de manera vertical u horizontal, al ser hundido otorga 4 puntos al atacante,\nestá representado por la letra 'D'.");


            Console.WriteLine($"\n\nLos símbolos '~' representan casillas donde se asume hay agua." +
                $"\nEl símbolo 'X' representa casillas donde atacaste y no impactaste." +
                $"\nEl símbolo 'O' representa casillas donde impactaste o recibiste un impacto (dependiendo del tablero).");
            
            Console.WriteLine($"\n\n\n\n\nPresiona cualquier tecla para continuar.");
            Console.ReadKey();
            Console.Clear();
        }
    }
}