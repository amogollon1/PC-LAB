﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace PROYECTO2_b
{
    /// <summary>
    /// Esta clase contiene las propiedades y métodos que definen a cada barco.
    /// </summary>
    class Barcos
    {
        public int[] submarino = new int[2]; // Dos casillas en horizontal,  otorga 2 puntos
        public int[] fragata = new int[2]; // Tres casillas en vertical,  otorga 3 puntos
        public int[] destructor = new int[2]; // Cuatro casillas horizontal o vertical,  otorga 4 puntos
        public int orientacionDestructor;
        public int vidaSubmarino;
        public int vidaFragata;
        public int vidaDestructor;
        /// <summary>
        /// Se inicializa la vida que tiene cada barco según la cantidad de casillas que ocupan.
        /// </summary>
        public Barcos()
        {
            this.vidaSubmarino = 2;
            this.vidaFragata = 3;
            this.vidaDestructor = 4;
        }

        /// <summary>
        /// Genera, aleatoriamente, la coordenada donde iniciará la generación de la posición del barco. Para hacerlo se usa un método random
        /// que varía dependiendo de la orientación de cada barco.
        /// </summary>
        /// <param name="orientacion">Recibe como argumento la orientación (vertical u horizontal) como un 0 o un 1</param>
        /// <param name="tamanaño">Recibe como arguento la cantidad de casillas que opcupa el barco y se implementa al momento de generar la coordenada aleatoria.</param>
        /// <returns></returns>
        public int[] GenerarPosicionInicial(int orientacion, int tamanaño) //Vertical = 0     Horizontal = 1
        {
            int[] arregloPosicion = new int[2];
            int columnaInicial = 2;
            int filaInicial = 2;
            if (orientacion == 0)
            {
                Random posicionInicial = new Random();
                filaInicial = posicionInicial.Next(0, 6 - tamanaño);
                columnaInicial = posicionInicial.Next(0, 6);
            }
            else if (orientacion == 1)
            {
                Random posicionInicial = new Random();
                filaInicial = posicionInicial.Next(0, 6);
                columnaInicial = posicionInicial.Next(0, 6 - tamanaño);
            }
            arregloPosicion[0] = filaInicial;
            arregloPosicion[1] = columnaInicial;

            return arregloPosicion;
        }
        /// <summary>
        /// Se guarda la posición inicial, generada en el método GenerarPosicionInicial(), en el arreglo de coordenadas del submarino.
        /// Se envían como parámetros la orientacion (horizntal = 1) y el tamaño de casillas que ocupa el barco.
        /// </summary>
        public void PosicionSubmarino()
        {
            this.submarino = GenerarPosicionInicial(1, 2);

        }
        /// <summary>
        /// Se guarda la posición inicial, generada en el método GenerarPosicionInicial(), en el arreglo de coordenadas de la fragata.
        /// Se envían como parámetros la orientacion (vertical = 0) y el tamaño de casillas que ocupa el barco.
        /// </summary>
        public void PosicionFragata()
        {
            this.fragata = GenerarPosicionInicial(0, 3);
        }
        /// <summary>
        /// Se guarda la posición inicial, generada en el método GenerarPosicionInicial(), en el arreglo de coordenadas del destructor.
        /// Se envían como parámetros la orientacion (vertical = 0 / horizntal = 1) y el tamaño de casillas que ocupa el barco.
        /// El destructor puede generarse de manera vertical u horizontal, esto se determina por medio de un random que se envía como parámetro.
        /// </summary>
        public void PosicionDestructor()
        {
            Random vertHor = new Random();
            this.orientacionDestructor = vertHor.Next(0, 2);

            this.destructor = GenerarPosicionInicial(this.orientacionDestructor, 4);
        }
    }
}
